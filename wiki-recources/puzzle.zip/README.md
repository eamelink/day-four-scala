Little puzzle solver

src/main/scala/PuzzlePicnic.scala holds the solver. Fill in the gaps here.
src/test/scala/puzzle/PuzzlePicnicSuite.scala holds the test suite for testing
your solution.

From the command-line run "sbt" and type "~test" to continuously check your 
solution. This will compile your code and run the test suite every time you 
save .scala files.