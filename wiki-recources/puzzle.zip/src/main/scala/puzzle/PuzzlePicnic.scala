/***********************
 * Little puzzle solver
 * 
 * Please fill in the
 * blanks (???)
 ***********************/

package puzzle

/**
 * Problem model
 */

/**
 * Edges are important in this model, so they have their own representation
 */
abstract class Edge

/**
 * Regular edge
 */
case class Single(a: Int, b: Int) extends Edge {
	/**
	 * @return true iff this Edge is connected to at least one node in nodes.
	 */
	def isConnectedEdge(nodes: Set[Int]) = nodes.contains(a) || nodes.contains(b)
	/**
	 * @return A set representation of the nodes connected to this edge.
	 */
	def nodes = Set(a, b)

	override def toString = "{" + a + "," + b + "}"
}

/**
 * Special edge that represents two potential edges that would cross
 * a1 a2
 *   X
 * b2 b1
 */
case class Cross(topLeft: Int, bottomRight: Int, topRight: Int, bottomLeft: Int) extends Edge

/**
 * The board we are trying to solve
 */
case class Board(nodes: List[Int], edges: List[Edge])

/*********************************************************************************************
 * The solver. We can make an instance from a Board and we can get all possible solutions from
 * #getPath
 *********************************************************************************************/

/**
 * static part
 */
object PuzzlePicnic {

	/**
	 * @return true iff all nodes don't have to many connections
	 */
	def isValidState(nodes: List[Int]): Boolean = ???
	
	/**
	 * @return true iff all nodes are fully satisfied
	 */
	def allSatisfied(nodes: List[Int]): Boolean = ???

}

/**
 * instance part
 */
class PuzzlePicnic(board: Board) {
	private val Board(nodes, edges) = board;
	private val usedNodeNumbers = availableNodesNumbers(nodes)

	/**
	 * Here can the solutions be retrieved
	 */
	lazy val paths = buildPath(edges, nodes, Nil)

	import puzzle.PuzzlePicnic.{isValidState, allSatisfied}
	/**
	 * Recursively brute-force our way to all possible solutions.
	 * @return a List of edge sets which each represent a valid solution such that all nodes are
	 * satisfied.
	 */
	private def buildPath(
		edges: List[Edge],
		nodeStates: List[Int],
		usedEdges: List[Single]
	): List[Set[Edge]] = edges match {
		case _ if (!isValidState(nodeStates)) => Nil
		case Nil =>
				if (allSatisfied(nodeStates) && isConnected(nodeStates, usedEdges)) List(usedEdges.toSet) 
				else Nil
		case (head @ Single(a, b)) :: tail => ???
		case Cross(a1, b1, a2, b2) :: tail => ???
	}

	/**
	 * @return A new list of nodes with the open connections decremented on the given nodes a and b
	 * in nodes.
	 */
	private def useNode(a: Int, b: Int, nodes: List[Int]) =
			nodes.patch(a, Seq(nodes(a) - 1), 1).patch(b, Seq(nodes(b) - 1), 1)

	/**
	 * @return The numbers of the nodes that need to have one or more connection. Nodes with no 
	 * required connections are not considered part of the search space.
	 */
	private def availableNodesNumbers(nodes: List[Int]) =
			nodes.zipWithIndex.filter(_._1 > 0).map(_._2).toSet

			
	/***************************************************************
	 * These are bonus, needed for filtering our disjoint solutions.
	 ***************************************************************/

	/**
	 * Please replace the catch all with the commented two lines.
	 * @return true iff given solution is a connected graph.
	 */
	private def isConnected(nodes: List[Int], edges: List[Single]) = edges match {
		case _ => true
//		case Nil => true
//		case (Single(a, b) :: tail) => findConnected(Set(a, b), tail) == usedNodeNumbers
	}

	/**
	 * @return All nodes in remaining and nodes that are (recursively) reachable from nodes.
	 */
	private def findConnected(nodes: Set[Int], remaining: List[Single]): Set[Int] = ???
}
