package puzzle

import org.scalatest.FlatSpec

class PuzzlePicnicSuite extends FlatSpec {
	val a = 0
	val b = 1
	val c = 2
	val d = 3
	val e = 4
	val f = 5
	val g = 6
	val h = 7
	val i = 8

	// a - b - c
	// | x | x |
	// d - e - f
	// | x | x |
	// g - h - i

	val a_b = Single(a, b)
	val b_c = Single(b, c)
	val d_e = Single(d, e)
	val e_f = Single(e, f)
	val g_h = Single(g, h)
	val h_i = Single(h, i)
	val a_d = Single(a, d)
	val b_e = Single(b, e)
	val c_f = Single(c, f)
	val d_g = Single(d, g)
	val e_h = Single(e, h)
	val f_i = Single(f, i)

	val a_e_b_d = Cross(a, e, b, d)
	val b_f_c_e = Cross(b, f, c, e)
	val d_h_e_g = Cross(d, h, e, g)
	val e_i_f_h = Cross(e, i, f, h)

	val _9x9 = List(
		a_b, b_c,
		d_e, e_f,
		g_h, h_i,
		a_d, b_e, c_f,
		d_g, e_h, f_i,
		a_e_b_d, b_f_c_e,
		d_h_e_g, e_i_f_h
	)

	// half crosses
	val a_e = Single(a, e)
	val b_d = Single(b, d)
	val b_f = Single(b, f)
	val c_e = Single(c, e)
	val d_h = Single(d, h)
	val e_g = Single(e, g)
	val e_i = Single(e, i)
	val f_h = Single(f, h)
	

	"isValidState" should "return true iff all numbers are positive" in {
		assert(PuzzlePicnic.isValidState(List(1, 2, 3, 4)))
		assert(!PuzzlePicnic.isValidState(List(-1, -2, 3, 4)))
		assert(PuzzlePicnic.isValidState(List(0, 0, 0, 0)))
	}
	
	"allSatisfied" should "return true iff all numbers are zero" in {
		assert(!PuzzlePicnic.allSatisfied(List(1, 2, 3, 4)))
		assert(!PuzzlePicnic.allSatisfied(List(1, 0, 0, 0)))
		assert(PuzzlePicnic.allSatisfied(List(0, 0, 0, 0)))
	}

	"getPath" should "solve 'fully' connected 4 nodes with one solution" in {
		// a - b      2 - 3
		// | x |  ->  | / |
		// d - e      3 - 2
	
	  	val nodes = List(
			2, 3, 0,
			3, 2, 0,
			0, 0, 0
	  	)
	
		val solutions = new PuzzlePicnic(Board(nodes, _9x9)).paths
		assert(solutions.length === 1)
		assert(solutions(0) === Set(a_b, a_d, b_e, d_e, Single(b, d)))
	}

	it should "solve complicated Single graph with one solution" in {
		// a--b--c  1  1--2
		//  \ | /    \   /
		//    e        3
		//  / | \        \
		// g--h--i  1--2--2
		
		val nodes = List(
			1, 1, 2,
			0, 3, 0,
			1, 2, 2
		)
		
		val solutions = new PuzzlePicnic(Board(nodes, _9x9)).paths
		assert(solutions.length === 1)
		assert(solutions(0) === Set(a_e, b_c, c_e, e_i, g_h, h_i))
	}

	it should "more crosses with three solutions" in {
		// a - b - c
		// | x | x |  ->
		// d - e - f
		
		// 2   3 - 2
		// | \ | \ |
		// 2 - 3   2
		
		// 2 - 3   2
		// | / | / |
		// 2 - 3 - 2
		
		// 2 - 3 - 2
		// |   |   |
		// 2 - 3 - 2

		val nodes = List(
			2, 3, 2,
			2, 3, 2,
			0, 0, 0
		)

		val solutions = new PuzzlePicnic(Board(nodes, _9x9)).paths
		assert(solutions.length === 3)
	}

	it should "more more crosses with eight solutions if findConnected is correct" in {
		// a - b - c      2 - 2   2
		// | x | x |      |   |   |
		// d - e - f  ->  2   2 - 2
		// | x | x |      |   |   |
		// g - h - i      2   2   2
		
		val nodes = List(
			2, 2, 2,
			2, 2, 2,
			2, 2, 2
		)

		val solutions = new PuzzlePicnic(Board(nodes, _9x9)).paths
		assert(solutions.length === 8)
	}
}
